from django.contrib import admin

from cinema.models import Cinema, City

# 


admin.site.register(City)
admin.site.register(Cinema)
